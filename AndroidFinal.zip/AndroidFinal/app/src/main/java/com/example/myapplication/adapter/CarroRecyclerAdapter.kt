package com.example.myapplication.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.entity.Carro
import kotlinx.android.synthetic.main.item_lista.view.*

class CarroRecyclerAdapter(): RecyclerView.Adapter<CarroRecyclerAdapter.ViewHolder>() {

    var onItemClickListener: ((Carro) -> Unit)? = null

    //cria uma lista vazia
    private var carroList = emptyList<Carro>()

    // inflar o item da lista no recycler view
    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_lista, parent, false)
        return ViewHolder(view)
    }

    // retorna o tamanho da lista
    override fun getItemCount(): Int = carroList.count()

    // insere os elementos da lista no item da lista do recycler
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val carro = carroList[position]
        holder.txt_Marca.text = carro.marca
        holder.txt_Modelo.text = carro.modelo
    }

    //atualiza os dados da lista
    fun setCarroList(carros:List<Carro>){
        this.carroList = carros
        notifyDataSetChanged()
    }

    // classe para mapear os componentes do item da lista
    inner class ViewHolder (view: View): RecyclerView.ViewHolder(view){

        init {
            itemView.setOnClickListener{
                onItemClickListener?.invoke(carroList[adapterPosition])
            }
        }

        val txt_Marca: TextView = view.txtMarca
        val txt_Modelo: TextView = view.txtModelo

    }
}