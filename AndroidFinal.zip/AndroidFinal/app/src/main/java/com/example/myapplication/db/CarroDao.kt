package com.example.myapplication.db


import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.myapplication.entity.Carro

@Dao
interface CarroDao {

    @Insert
    fun insert (carro: Carro)

    @Update
    fun update(carro: Carro)

    @Delete
    fun delete(carro: Carro)

    @Query("SELECT * FROM carro_table  ORDER BY marca ASC")
    fun getAll(): LiveData<List<Carro>>

    @Query("SELECT * FROM carro_table WHERE id = :id_")
    fun getCarro(id_ : Long): LiveData<Carro>

    @Query("DELETE FROM carro_table")
    fun deleteAll()

}