package com.example.myapplication.entity


import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import org.jetbrains.annotations.NotNull
import java.io.Serializable

@Entity(tableName = "carro_table")
class Carro (

    @NotNull
    @ColumnInfo(name = "marca")
    var marca: String = "",

    @ColumnInfo(name = "modelo")
    var modelo: String = "",

    @ColumnInfo(name = "cor")
    var cor: String = "",

    @ColumnInfo(name = "ano")
    var ano: Int = 0,

    @ColumnInfo(name = "descricao")
    var descricao: String = ""

):Serializable{

    @PrimaryKey(autoGenerate = true)
    var id: Long = 0

}