package com.example.myapplication.repository



import androidx.lifecycle.LiveData
import com.example.myapplication.db.CarroDao
import com.example.myapplication.entity.Carro

class CarroRepository(private val carroDao: CarroDao) {

    val allCarros: LiveData<List<Carro>> = carroDao.getAll()

    fun insert(carro: Carro){
        carroDao.insert(carro)
    }

    fun update(carro: Carro){
        carroDao.update(carro)
    }

    fun delete(carro: Carro){
        carroDao.delete(carro)
    }

}