package com.example.myapplication.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.R
import com.example.myapplication.entity.Carro
import kotlinx.android.synthetic.main.activity_carro.*
import java.lang.Exception

class CarroActivity : AppCompatActivity() {

    lateinit var carro: Carro

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_carro)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // ======= [ receber os dados da intent caso já exista o objeto]

        val intent = intent
        try{
            carro = intent.extras?.get(EXTRA_REPLY) as Carro
            carro.let{
                etMarca.setText(it.marca)
                etModelo.setText(it.modelo)
                etCor.setText(it.cor)
                etAno.setText(it.ano.toString())
                etCor.setText(it.descricao)
            }
        } catch (e: Exception){
            Log.e("TAG: ", e.message)
        }

    }

    private fun populaObjeto(){

        if(etMarca.text.isNotEmpty()){
            carro.marca = etMarca.text.toString()
        }

        if(etModelo.text.isNotEmpty()){
            carro.modelo = etModelo.text.toString()
        }

        if(etCor.text.isNotEmpty()){
            carro.cor = etCor.text.toString()
        }


        if(etAno.text.isNotEmpty()){
            carro.ano = etAno.text.toString().toInt()
        }

    }

    // ==== [begin menu] ==========

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_projeto, menu)

        try {
            carro.let {
                val menuItem = menu?.findItem(R.id.menu_excluir)
                menuItem?.isVisible = true
            }
        } catch (e: Exception){
            Log.e("TAG: ", "Novo item " + e.message)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {

        return if(item?.itemId == android.R.id.home){
            finish()
            true
        } else if (item?.itemId == R.id.menu_save){
            val retornaIntent = Intent()

            if(etModelo.text.isNullOrEmpty()){
                Toast.makeText(this, "O modelo não pode ser vazio", Toast.LENGTH_LONG).show()

            } else if(etCor.text.isNullOrEmpty()){
                Toast.makeText(this, "A cor não pode ser vazia", Toast.LENGTH_LONG).show()


            } else if(etAno.text.isNullOrEmpty()){
                Toast.makeText(this, "Ano não pode estar vazio", Toast.LENGTH_LONG).show()

            } else {
                try {
                    if ((::carro.isInitialized) && carro.id > 0){
                        populaObjeto()
                    } else {
                        carro = Carro()
                        populaObjeto()
                    }
                    retornaIntent.putExtra(EXTRA_REPLY, carro)
                } catch (e: Exception){
                    setResult(Activity.RESULT_CANCELED, retornaIntent)
                }
                setResult(Activity.RESULT_OK, retornaIntent)
                finish()
            }
            true

        } else if(item?.itemId == R.id.menu_excluir){
            if((::carro.isInitialized) && carro.id > 0){
                val replyIntent = Intent()
                replyIntent.putExtra(EXTRA_DELETE, carro)
                setResult(Activity.RESULT_OK, replyIntent)
                finish()
            }
            true
        } else {
            return super.onOptionsItemSelected(item)
        }
    }

    // ==== [end menu] ============

    companion object{
        const val EXTRA_REPLY = "com.example.myapplication.ui.REPLY"
        const val EXTRA_DELETE = "com.example.myapplication.ui.DELETE"
    }

}