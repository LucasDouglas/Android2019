package com.example.myapplication.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.adapter.CarroRecyclerAdapter
import com.example.myapplication.viewmodel.CarroViewModel
import kotlinx.android.synthetic.main.activity_lista_carro.*
import java.lang.Exception
import androidx.lifecycle.Observer
import com.example.myapplication.entity.Carro


class ListaCarroActivity : AppCompatActivity() {

    private lateinit var carroViewModel: CarroViewModel
    lateinit var notificationManager: NotificationManagerCompat

    val REQUEST_CODE = 12
    val REQUEST_CODE_UPDATE = 13
    val CHANNEL_ID = "com.example.myapplication.ui.CHANNEL_ID"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_carro)

        notificationManager = NotificationManagerCompat.from(this)

        val recyclerView_: RecyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        montaLista(recyclerView_)

        btnNovo.setOnClickListener {
            val intent = Intent(
                this,
                CarroActivity::class.java
            )
            startActivityForResult(intent, REQUEST_CODE)
        }
    }

    private fun montaLista(recyclerView_: RecyclerView) {
        recyclerView_.setHasFixedSize(true)

        // responsável por medir e posicionar as visualizações dos itens
        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)

        recyclerView_.layoutManager = layoutManager

        val adapter = CarroRecyclerAdapter()

        adapter.onItemClickListener = { it ->
            val intent = Intent(this@ListaCarroActivity,
                CarroActivity::class.java)
            intent.putExtra(CarroActivity.EXTRA_REPLY, it)
            startActivityForResult(intent, REQUEST_CODE_UPDATE)
        }

        recyclerView_.adapter = adapter

        carroViewModel = ViewModelProviders.of(this).get(CarroViewModel::class.java)

        // recebe todos os dados do banco e atualiza no adapter
        carroViewModel.allCarro.observe(this, Observer { bikes -> bikes?.let { adapter.setCarroList(it) } })

    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            data?.let { resultado ->
                try {
                    val carro = resultado.extras?.get(CarroActivity.EXTRA_REPLY) as Carro
                    carro.let {
                        carroViewModel.insert(carro)
                    }
                } catch (e: Exception) {
                    Log.d("TAG: ", e.message)
                }
            }
        } else if (requestCode == REQUEST_CODE_UPDATE && resultCode == Activity.RESULT_OK) {

            data?.let { resultado ->
                try {
                    var carro : Carro? = resultado.extras?.get(CarroActivity.EXTRA_REPLY) as? Carro

                    if (carro == null) {
                        carro = resultado.extras?.get(CarroActivity.EXTRA_DELETE) as? Carro
                        carro.let {
                            //mostra notificação
                            showNotification("Exclusão realizada", it!!.marca)
                            //exclui objeto
                            carroViewModel.delete(it)
                        }
                    } else {
                        carro.let { carroViewModel.update(carro) }
                    }
                } catch (e: Exception) {
                    Log.d("TAG: ", e.message)
            }

        }
            }
        }

    //cria notificação
    private fun showNotification(titulo: String, conteudo: String) {
        val notification =
           NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_delete)
                .setContentTitle(titulo)
                .setContentText(conteudo)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
        notificationManager.notify(1, notification)
    }
}



