package com.example.myapplication.viewmodel


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.myapplication.db.CarroDatabase
import com.example.myapplication.entity.Carro
import com.example.myapplication.repository.CarroRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext

class CarroViewModel(application: Application): AndroidViewModel(application) {

    private val parentJob = Job()
    private val coroutineContext: CoroutineContext
    get() = parentJob + Dispatchers.Main
    private val scope = CoroutineScope(coroutineContext)

    private val repository: CarroRepository
    val allCarro: LiveData<List<Carro>>

    init {
        val carroDao = CarroDatabase.getDatabase(application).carroDao()
        repository = CarroRepository(carroDao)
        allCarro = repository.allCarros
    }

    fun insert(carro: Carro) = scope.launch(Dispatchers.IO) {
        repository.insert(carro)
    }

    fun update(carro: Carro) = scope.launch(Dispatchers.IO){
        repository.update(carro)
    }

    fun delete(carro: Carro) = scope.launch(Dispatchers.IO){
        repository.delete(carro)
    }

}