package com.example.android

import android.support.v7.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sb_Idade.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                tv_Idade.text = progress.toString()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }
        })
        sb_Peso.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                tv_Peso.text = progress.toString()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })
        sb_Altura.max = ((2 - 0) / 0.01).toInt()
        sb_Altura.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                var customizado = 0 + (progress * 0.01)
                tv_Altura.text = customizado.toString()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })
        rg_Sexo.setOnCheckedChangeListener{ rg_Sexo, checkedId ->

                val radio : RadioButton = findViewById(checkedId)
                Toast.makeText(applicationContext,"Sexo : ${radio.text}",
                    Toast.LENGTH_SHORT).show()
                }
        btn_Calcular.setOnClickListener{
            rg_Sexo.checkedRadioButtonId.toString()
            val ideal = tv_Peso.text.toString().toFloat() / (tv_Altura.text.toString().toFloat() * tv_Altura.text.toString().toFloat())
            if(rb_Masculino.isChecked){
                when(ideal) {
                    in 1.0..19.0 -> tv_Resultado.text = " Você é Homem" + " seu IMC é " + "%.2f".format( ideal) + ", abaixo do peso"
                    in 19.0 ..25.0  -> tv_Resultado.text =" Você é Homem" + " seu IMC é " + "%.2f".format( ideal) + ", peso normal"
                    in 25.0 ..30.0  -> tv_Resultado.text =" Você é Homem" + " seu IMC é " + "%.2f".format( ideal) + ", sobrepeso"
                    else -> tv_Resultado.text = " Você é Homem" + " seu IMC é " + "%.2f".format( ideal) + ", obeso"
                }
            }
            else{
                when(ideal) {
                    in 1.0..19.0 -> tv_Resultado.text = " Você é mulher" + " seu IMC é " + "%.2f".format( ideal) + ", abaixo do peso"
                    in 19.0 ..25.0  -> tv_Resultado.text = " Você é mulher" + " seu IMC é " + "%.2f".format( ideal) + ", peso normal"
                    in 25.0 ..30.0  -> tv_Resultado.text = " Você é mulher" + " seu IMC é " + "%.2f".format( ideal) + ", sobrepeso"
                    else -> tv_Resultado.text = " Você é mulher" + " seu IMC é " + "%.2f".format( ideal) + ", obeso"
                }
            }
        }


        btn_Treino.setOnClickListener {
            val mudarPage = Intent(this, Treino::class.java)
            startActivity(mudarPage)
        }

        btn_Treino.setOnClickListener {
            val mudarPage = Intent(this, Treino::class.java)
            startActivity(mudarPage)
        }

      val ratingBar = findViewById<RatingBar>(R.id.rb_Avaliacao)
      if (ratingBar != null) {
        val msg = ratingBar.rating.toString()
        Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
      }

    }
}
