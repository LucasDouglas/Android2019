package com.example.android

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_treino.*

class Treino : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_treino)

        val Texto = arrayOf("Selecione o Treino monstro","A","B","C")
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            Texto
        )
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line)
        sp_Treinos.adapter = adapter;
        sp_Treinos.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long){
                val textoSelecinado = "${parent.getItemAtPosition(position).toString()}"
                if(textoSelecinado.equals("Selecione o Treino monstro")){
                    tv_Treinos.text = ""
                }else if(textoSelecinado.equals("A")){
                    tv_Treinos.text = "Agachamento – 5 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Leg press – 4 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Extensora – 3 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Stiff – 4 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Mesa flexora – 3 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Extensora lombar – 3 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Panturrilha – 4 séries de 8 a 10 repetições com 1 minuto de intervalo.\n"
                }else if(textoSelecinado.equals("B")){
                    tv_Treinos.text = "Supino – 5 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Supino inclinado com halteres – 4 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Peck deck fly – 3 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Desenvolvimento – 4 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Elevação lateral – 3 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Mergulho – 3 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Tríceps corda – 3 séries de 8 a 10 repetições com 1 minuto de intervalo.\n"
                }
                else if(textoSelecinado.equals("C")){
                    tv_Treinos.text = "Barra fixa ou graviton – 5 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Remada baixa no triângulo – 4 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Puxada alta – 3 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Rosca alternada – 3 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Rosca direta no cabo – 3 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Abdominal crunch na máquina – 3 séries de 8 a 10 repetições com 1 minuto de intervalo;\n" +
                            "Abdominal oblíquo na máquina – 3 séries de 8 a 10 repetições com 1 minuto de intervalo.\n"
                }

            }
            override fun onNothingSelected(parent: AdapterView<*>){
            }
        }
      val calendarView = findViewById<CalendarView>(R.id.cv_Data)
      calendarView?.setOnDateChangeListener { view, year, month, dayOfMonth ->

        val msg = "Selected date is " + dayOfMonth + "/" + (month + 1) + "/" + year
        Toast.makeText(this@Treino, msg, Toast.LENGTH_SHORT).show()
      }
      val ratingBar = findViewById<RatingBar>(R.id.rb_Avalicao2)
      if (ratingBar != null) {
          val msg = ratingBar.rating.toString()
          Toast.makeText(this@Treino, msg, Toast.LENGTH_SHORT).show()
        }




      btn_IMC.setOnClickListener {
            val mudarPage = Intent(this, MainActivity::class.java)
            startActivity(mudarPage)
        }

    }
}
